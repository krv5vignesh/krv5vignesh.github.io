import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Login from './Login';
import Register from './Register';
import AddCustomer from './AddCustomer'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';


class AdminsData extends Component{
  render(){
    var admins = this.props.admins
    var tableData = admins.map(function(i){
          console.log(i)
          return <tr><td>{i.name}</td><td>{i.username}</td><td>{i.password}</td></tr>
        })
        console.log(tableData)
    return(
      <table border="solid">
        {tableData}
      </table> 
    )
  }
}
class App extends Component {
  constructor(){
    super()
    this.state = {
      admins: [{name:"Admin", username:"admin", password:"admin"}],
      validUser: false,
      showRegister: false,
      showLogin: true,
      loginRegister: "Register",
      registeredMessage: null,
      showLoginErrorMessage: false
    }
  }
  registerAdmins(value){
    this.state.admins.push(value);
    this.setState(this.state)
    this.setState({registeredMessage: "Successfully Registered"})
  }
  loginAdmins(value){
    if(value)
      this.setState({validUser: true, showLoginErrorMessage: false, showLogin: false, loginRegister: "Logout"})
    else{
      console.log("Not a valid user")
      this.setState({showLoginErrorMessage: true})
    }
  }
  showRegister(){
    if(this.state.loginRegister == "Logout")
      this.setState({showRegister: false, showLogin: true, registeredMessage: "", showLoginErrorMessage: false, loginRegister: "Register", validUser: false})
    else{
      this.setState({showRegister: !this.state.showRegister, showLogin: !this.state.showLogin, registeredMessage: "", showLoginErrorMessage: false})
      if(this.state.loginRegister == "Register")
        this.state.loginRegister = "Back"
      else
        this.state.loginRegister = "Register"    
    }
  }
  render() {
      console.log(this.state.showLogin)
      console.log(this.state.showRegister)
      var validUser = false;
      return (
      <div className="App">
        {this.state.showRegister ? <Register admins={this.state.admins} loginRegister={this.registerAdmins.bind(this)} /> : this.state.showLogin? <Login admins={this.state.admins} validUserCheck={this.loginAdmins.bind(this)}/> : null}
        {this.state.validUser && (this.state.showLogin == false)? <AddCustomer /> :null}
        <br />                
        <a href="#" onClick={this.showRegister.bind(this)}>{this.state.loginRegister}</a>
        <br />
        <h5 style={{color:"green"}}>{this.state.registeredMessage}</h5>
        {/*<AdminsData admins={this.state.admins} ></AdminsData>*/}
        {this.state.showLoginErrorMessage? <h5 style={{color:"red"}}>Invalid User</h5> : null}
        
      </div>
    );
  }
}

export default App;