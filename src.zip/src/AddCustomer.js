import React, { Component } from 'react';

class City extends Component{
    constructor(){
        super()
        this.state = {
            cities: ["Chennai", "Madurai", "Mumbai", "Bangalore", "Delhi"]
        }
    }
    render(){
        var cities = this.state.cities.map(function(i){
            return <option value={i}>{i}</option>
        })
        return(
            <select>{cities}</select>
        )
    }
}

class State extends Component{
    constructor(){
        super()
        this.state = {
            states: ["Tamil Nadu", "Karnataka", "Maharastra", "Goa", "Delhi"]
        }
    }
    render(){
        var states = this.state.states.map(function(i){
            return <option value={i}>{i}</option>
        })
        return(
            <select>{states}</select>
        )
    }
}

class AddCustomer extends Component{
    render(){
        return(
            <div>
                First Name: <input type="text" ref="cfname" /><br />
                Last Name: <input type="text" ref="clastname" /><br />
                City: <City /><br />
                State: <State /><br />
                Email: <input type="email" ref="cmail" /><br />
                <input type="submit" />
            </div>
        )
    }
}

export default AddCustomer;