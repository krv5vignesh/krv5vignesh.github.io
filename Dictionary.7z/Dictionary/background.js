var callbackfn = function(data){
    
        console.log("Inside");
        console.log(data);    
        var definition = "";
        
            if(data.tuc && data.tuc[0] && data.tuc[0].meanings){
                var count = 0;
                data.tuc[0].meanings.forEach((i, index)=> {
                    console.log(index);
                    if(index>=0 && count<5){
                        definition += ++index+". "+i.text+"<br />"
                        count++;
                    }
                });
            }else{
                definition = "No result found"
            }
            //$( "#result" ).html(definition);
            //alert(definition);
            console.log(definition);
       
}
console.log("vanilla js");
$(document).ready(function(){
    console.log("should have opened");
});
// browser.browserAction.onClicked.addListener(function(tab){
//     console.log("clicked");
//     browser.tabs.executeScript({
//         code: "document.body.style.border = '5px solid blue'"
//     });
// });

$(document).dblclick(function(){
    console.log("There was a double-click");
    setTimeout(() => {dblclickSlection();}, 300);
});
function dblclickSlection(){
    flag = 0;
    if (window.getSelection) {
        selectedText = window.getSelection();
    } else if (document.getSelection) {
        selectedText = document.getSelection();
    } else if (document.selection) {
        selectedText = document.selection.createRange().text;
    }
    console.log("Selected text is "+typeof(selectedText));
    search(selectedText.toString());
}        
function search(selectedText){
    console.log("Double click search"+typeof(selectedText));
    var query = selectedText;
    $('#query').val(query);
    console.log("invoked "+query+" "+typeof(query));
    query = query.replace(" ", "");
    query = query.toLowerCase();
    console.log(query);
    //$( "#result" ).html("Searching...");
    $.getJSON("https://glosbe.com/gapi/translate?from=eng&dest=eng&format=json&phrase="+query+"&callback=?", function(data){
        console.log(success+" "+data);
    }).fail(function(d, textStatus, error) {
        console.log("Error retrieving data. Check your connection."+d+" "+textStatus+" "+error);
        //$( "#result" ).html("Error retrieving data. Check your connection.");
        //alert("Error retrieving data. Check your connection."+error);
    });
}
