console.log("Loadasdfed");
//alert("asdf")
document.body.style.border = "5px solid red";
document.getElementsByTagName('body').addEventListener("click", function(){
    console.log("Double clicked");
});
// $(document).dblclick(function(){
//     console.log("There was a double-click");
//     setTimeout(() => {dblclickSlection();}, 300);
// });
// function dblclickSlection(){
//     flag = 0;
//     if (window.getSelection) {
//         selectedText = window.getSelection();
//     } else if (document.getSelection) {
//         selectedText = document.getSelection();
//     } else if (document.selection) {
//         selectedText = document.selection.createRange().text;
//     }
//     console.log("Selected text is "+typeof(selectedText));
//     search(selectedText.toString());
// }        

// function search(selectedText){
//     console.log("Double click search");
//     var query = selectedText;
//     $('#query').val(query);
//     console.log("invoked "+query+" "+typeof(query));
//     query = query.replace(" ", "");
//     query = query.toLowerCase();
//     $( "#result" ).html("Searching...");
//     $.getJSON("https://glosbe.com/gapi/translate?from=eng&dest=eng&format=json&phrase="+query+"&callback=?", function( data ) {
//         var definition = "";
//         if(data.tuc && data.tuc[0] && data.tuc[0].meanings){
//             var count = 0;
//             data.tuc[0].meanings.forEach((i, index)=> {
//                 console.log(index);
//                 if(index>=0 && count<5){
//                     definition += ++index+". "+i.text+"<br />"
//                     count++;
//                 }
//             });
//         }else{
//             definition = "No result found"
//         }
//         //$( "#result" ).html(definition);
//         alert(definition);
//         console.log(data);
//     }).fail(function(error) {
//         console.log("Error retrieving data. Check your connection."+error);
//         //$( "#result" ).html("Error retrieving data. Check your connection.");
//         alert("Error retrieving data. Check your connection."+error);
//     });
// }