console.log("background");

browser.runtime.onMessage.addListener(search);
function handleMessage(request, sender, sendResponse){
    var result = search(request);
    console.log(result);
    console.log(sender);
    sendResponse({response: "result"});
}

function search(message, sender, sendResponse){
    console.log("Received"+message);
    var query = message.term;
    console.log("invoked "+query+" "+typeof(query));
    query = query.replace(" ", "");
    query = query.toLowerCase();
    var definition="";
    $.getJSON("https://glosbe.com/gapi/translate?from=eng&dest=eng&format=json&phrase="+query+"&callback=?", function( data ) {
        if(data.tuc && data.tuc[0] && data.tuc[0].meanings){
            var count = 0;
            definition = query+"/n";
            data.tuc[0].meanings.forEach((i, index)=> {
                if(index>=0 && count<5){
                    definition += ++index+". "+i.text+"<br />"
                    count++;
                }
            });
        }else{
            definition = "No result found";
        }
            console.log(definition);
            
            localStorage.setItem("result", definition);
            //sendResponse({response: definition});
        }).fail(function(error, a, b) {
            console.log("Error retrieving data. Check your connection."+error+" "+a+" "+b);
        }
    );
    var temp = localStorage.getItem("result")
  console.log(temp);
  sendResponse({response: temp});
  //browser.tabs.sendMessage({result: definition});
}
//console.log("Defintion "+definition);