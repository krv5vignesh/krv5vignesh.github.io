console.log("asdf");

$(document).dblclick(function(){
    console.log("Clicked");
    dblclickSlection();
});

function dblclickSlection(){
    flag = 0;
    if (window.getSelection) {
        selectedText = window.getSelection();
    } else if (document.getSelection) {
        selectedText = document.getSelection();
    } else if (document.selection) {
        selectedText = document.selection.createRange().text;
    }
    console.log("Selected text is "+selectedText+" "+typeof(selectedText));
    browser.runtime.sendMessage({"term": selectedText.toString()}).then(handleResponse, handleError);
    console.log("Sent");
}
function handleResponse(message){
    console.log("Response received "+message.response);
}
function handleError(error){
    console.log("Error: "+error);
}