console.log("loaded");

document.getElementById("query").focus();
document.getElementById("submitButton").addEventListener("click", function(event) {
    console.log("Button clicked");
    search();
  });
function search(){
    var query = $('#query').val();
    console.log("invoked");
    //$("#dictionary").load("https://www.google.com/search?q=define+"+query+" #dictionary-modules");
    //window.open("https://www.google.com/search?q=define+"+query+" #dictionary-modules", "", "location=no, scrollbars=no resizable=no,width=620,height=400");
    //var APIkey = "dict.1.1.20171128T091000Z.5f4042af6f211f39.9640ec2af29124a49fd0526659affdb8bf29dea7";
    //$.get("https://dictionary.yandex.net/api/v1/dicservice.json/lookup?key="+APIkey+"&lang=en-en&text="+query, function( data ) {
       $.getJSON("https://glosbe.com/gapi/translate?from=eng&dest=eng&format=json&phrase="+query+"&callback=?", function( data ) {
        var definition = "";
        if(data.tuc && data.tuc[0] && data.tuc[0].meanings){
            data.tuc[0].meanings.forEach((i, index)=> {
                if(index!=0 && index<=5)
                    definition += index+". "+i.text+"<br />"
            });
        }else{
            definition = "No result found"
        }
        $( "#result" ).html(definition);
        console.log(data);
    }).fail(function() {
        console.log("Error retrieving data.");
  });
}

