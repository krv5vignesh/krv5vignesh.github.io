import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Login from './Login';
import Register from './Register'
import Router from 'react-router'
import Route from 'react-router'

class AdminsData extends Component{
  render(){
    var admins = this.props.admins
    var tableData = admins.map(function(i){
          console.log(i)
          return <tr><td>{i.name}</td><td>{i.username}</td><td>{i.password}</td></tr>
        })
        console.log(tableData)
    return(
      <table border="solid">
        {tableData}
      </table> 
    )
  }
}
class App extends Component {
  constructor(){
    super()
    this.state = {
      admins: [],
      validUser: false,
      showRegister: false,
      loginRegister: "Register",
      registeredMessage: null
    }
  }
  registerAdmins(value){
    this.state.admins.push(value);
    this.setState(this.state)
    this.setState({registeredMessage: "Successfully Registered"})
  }
  loginAdmins(value){
    this.setState({validUser: true})
  }
  showRegister(){
    this.setState({showRegister: !this.state.showRegister, registeredMessage: ""})
    if(this.state.loginRegister=="Register")
      this.state.loginRegister = "Back"
    else
      this.state.loginRegister = "Register"    
  }
  render() {
      var validUser = false;
      return (
      <div class="App">
        {this.state.showRegister? <Register admins={this.state.admins} loginRegister={this.registerAdmins.bind(this)} /> : <Login admins={this.state.admins} validUserCheck={this.loginAdmins.bind(this)}/>}
        <br />                
        <a href="#" onClick={this.showRegister.bind(this)}>{this.state.loginRegister}</a>
        <br />
        <h5 style={{color:"green"}}>{this.state.registeredMessage}</h5>
        {/*<AdminsData admins={this.state.admins} ></AdminsData>*/}
        <Router>
          <Route path="./Register" component={Register}>Register</Route>
        </Router>
      </div>
    );
  }
}

export default App;