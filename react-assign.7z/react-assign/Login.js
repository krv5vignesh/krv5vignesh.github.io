import React, { Component } from 'react';

class Login extends Component{
    loginCheck(){
        var adminsData = this.props.admins
        var username = this.refs.lUsername.value
        var password = this.refs.lPassword.value
        console.log(adminsData)
        console.log(this.props.validUser)
        for(var i in adminsData){
            console.log(adminsData[i].username+" "+adminsData[i].password)
            if((username==adminsData[i].username) && (password==adminsData[i].password)){
                console.log("This is a valid user")
                this.props.validUserCheck(true)
            }
        }
    }
    render(){
        return(
            <div>
                <h1>Admin Login Page</h1><br />
                Username: <input type="text" ref="lUsername" /><br /><br />
                Password: <input type="password" ref="lPassword" /><br /><br />
                <input type="submit" onClick={this.loginCheck.bind(this)}/>
            </div>
        )
    }
}

export default Login;