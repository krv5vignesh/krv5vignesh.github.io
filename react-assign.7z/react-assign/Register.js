import React, { Component } from 'react';

class Register extends Component{
  loginUser(){
    console.log(this.props.admins)
    //this.props.admins.push({"name":this.refs.nametb.value, "username": this.refs.usernametb.value, "password": this.refs.passwordtb.value});
    this.props.loginRegister({"name":this.refs.nametb.value, "username": this.refs.usernametb.value, "password": this.refs.passwordtb.value})
  }
  render(){
    console.log(this.props.admins)
    return(
      <div>
        <h1>Registration Page</h1><br />
        Name: <input type="text"  ref="nametb"/><br /><br />
        Username: <input type="text"  ref="usernametb"/><br /><br />
        Password: <input type="password"  ref="passwordtb" /><br /><br />
        <input type="submit" onClick={this.loginUser.bind(this)} />
      </div> 
    )
  }
}

export default Register;